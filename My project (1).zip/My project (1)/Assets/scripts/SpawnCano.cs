using UnityEngine;

public class SpawnCano : MonoBehaviour
{
    public GameObject prefabs;
    public float spawnCano = 1f;
    public float velocidadeMin = -0.5f;
    public float velocidadeMax = 0.5f;
    public float velocidade = 5;

    private void OnEnable()
    {
        InvokeRepeating(nameof(Spawn), spawnCano, spawnCano);
    }

    private void OnDisable()
    {
        CancelInvoke(nameof(Spawn));
    }

    private void Spawn()
    {
        GameObject canos = Instantiate(prefabs, transform.position, Quaternion.identity);
        canos.transform.position += Vector3.up * Random.Range(velocidadeMin, velocidadeMax);
        velocidade += (float)0.4;
        Cano[] canosM = Object.FindObjectsByType<Cano>(FindObjectsInactive.Include, FindObjectsSortMode.None);
        for (int i = 0; i < canosM.Length; i++)
        {
            canosM[i].velocidade = velocidade;
        }
    }
}
