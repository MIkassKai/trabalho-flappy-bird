﻿public class newvoid
{
}