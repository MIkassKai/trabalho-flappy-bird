using UnityEngine;

public class Lingyang : player
{
    protected override void Awake()
    {
      base.Awake();
    }
    
    protected override void Start()
    {
        base.Start();
    }

    protected override void Update()
    {
        if (Input.GetKeyDown(KeyCode.Space))
        {
            direcao = Vector3.up * forca;
        }
        direcao.y += gravidade * Time.deltaTime;
        transform.position += direcao * Time.deltaTime;
    }

    protected override void OnTriggerEnter2D(Collider2D other)
    {
        base.OnTriggerEnter2D (other);
    }
}
