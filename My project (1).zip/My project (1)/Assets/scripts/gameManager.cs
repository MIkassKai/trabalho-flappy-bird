using Mono.Cecil;
using TMPro;
using UnityEngine;
using UnityEngine.SocialPlatforms.Impl;
using UnityEngine.UI;

public class gameManager : MonoBehaviour
{
    private int pontos;
    public TextMeshProUGUI pontosTexto;
    public GameObject gameOver;
    public GameObject comeco;
    public GameObject comecoPhoebe;
    public GameObject comecoLingYang;
    public GameObject poderLin;
    public GameObject poderPho;
    public player player1;
    public player player2;
    public float velocidade = 5f;

    private void Awake()
    {
        Application.targetFrameRate = 60;
        gameOver.SetActive(false);
        comeco.SetActive(false);
        poderLin.SetActive(true);
        poderPho.SetActive(true);
        Pause();
    }
    public void PlayLin()
    {
        pontos = 0;
        pontosTexto.text = pontos.ToString();
        comeco.SetActive(false);
        gameOver.SetActive(false);
        poderLin.SetActive(false);
        poderPho.SetActive(false);
        Time.timeScale = 1f;
        player1.enabled = true;
        player2.enabled = false;
        Cano[] canos = Object.FindObjectsByType<Cano>(FindObjectsInactive.Include, FindObjectsSortMode.None);
        for (int i = 0; i < canos.Length; i++)
        {
            Destroy(canos[i].gameObject);
        }
        Phoebe phoebe = FindFirstObjectByType<Phoebe>();
        phoebe.gameObject.SetActive(false);
        SpawnCano canoV = FindFirstObjectByType<SpawnCano>();
        canoV.velocidade = 5f;
    }
    public void PlayPho()
    {
        pontos = 0;
        pontosTexto.text = pontos.ToString();
        comeco.SetActive(false);
        gameOver.SetActive(false);
        poderLin.SetActive(false);
        poderPho.SetActive(false);
        Time.timeScale = 1f;
        player1.enabled = false;
        player2.enabled = true;
        Cano[] canos = Object.FindObjectsByType<Cano>(FindObjectsInactive.Include, FindObjectsSortMode.None);
        for (int i = 0; i < canos.Length; i++)
        {
            Destroy(canos[i].gameObject);
        }
        Lingyang lingyang = FindFirstObjectByType<Lingyang>(); 
        lingyang.gameObject.SetActive(false );
        SpawnCano canoV = FindFirstObjectByType<SpawnCano>();
        canoV.velocidade = 5f;
    }


    public void Pause()
    {
        Time.timeScale = 0;
        player2.enabled = false;
        player1.enabled = false;
    }
    public void FimDeJogo()
    {
        gameOver.SetActive(true);
        comeco.SetActive(false);
        poderLin.SetActive(true);
        poderPho.SetActive(true);
        Lingyang[] lingyang = Object.FindObjectsByType<Lingyang>(FindObjectsInactive.Include, FindObjectsSortMode.None);
        for (int i = 0; i < lingyang.Length; i++)
        {
            lingyang[i].gameObject.SetActive(true);
        }
        Phoebe[] phoebe = Object.FindObjectsByType<Phoebe>(FindObjectsInactive.Include, FindObjectsSortMode.None);
        for (int i = 0; i < phoebe.Length; i++)
        {
            phoebe[i].gameObject.SetActive(true);
        }
        Pause();
    }
    public void MaisPonto()
    {
        pontos++;
        pontosTexto.text = pontos.ToString();
    }

}
