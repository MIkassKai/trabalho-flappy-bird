using UnityEngine;

public class Cano : MonoBehaviour
{
    public float velocidade = 5f;
    private float esquerda;

    private void Start()
    {
        esquerda = Camera.main.ScreenToWorldPoint(Vector3.zero).x - 1f;
    }
    private void Update()
    {
        transform.position += Vector3.left * velocidade * Time.deltaTime;
        if (transform.position.x < esquerda)
        {
            Destroy(gameObject);
        }
    }
}
