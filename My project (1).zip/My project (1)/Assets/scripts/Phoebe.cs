using UnityEngine;

public class Phoebe : player
{
    protected override void Awake()
    {
        base.Awake();
    }

    protected override void Start()
    {
        base.Start();
    }

    protected override void Update()
    {
        if (Input.GetKeyDown(KeyCode.Space))
        {
            direcao = Vector3.up * forca/2;
        }
        direcao.y += gravidade * Time.deltaTime;
        transform.position += direcao * Time.deltaTime;
    }

    protected override void OnTriggerEnter2D(Collider2D other)
    {

        if (other.gameObject.tag == "obstaculo")
        {
            FindFirstObjectByType<gameManager>().FimDeJogo();
        }
        else if (other.gameObject.tag == "score")
        {
            FindFirstObjectByType<gameManager>().MaisPonto();
            FindFirstObjectByType<gameManager>().MaisPonto();
        }
    }
}

