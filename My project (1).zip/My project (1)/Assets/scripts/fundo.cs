using UnityEngine;

public class fundo : MonoBehaviour
{
    private MeshRenderer meshRenderer;
    public float velocidadeAnimacao2 = 0.3f;

    private void Awake()
    {
        meshRenderer = GetComponent<MeshRenderer>();
    }

    private void Update()
    {
        meshRenderer.material.mainTextureOffset += new Vector2(velocidadeAnimacao2 * Time.deltaTime, 0); 
    }
}
