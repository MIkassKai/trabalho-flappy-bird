using System;
using UnityEngine;

public class player : MonoBehaviour
{
    protected SpriteRenderer spriteRenderer;

    protected Vector3 direcao;

    public float gravidade = -9.8f;

    public float forca = 5f;

    public Sprite[] sprites;

    protected int spriteIndex;

    protected virtual void Awake()
    {
        spriteRenderer = GetComponent<SpriteRenderer>();
    }

    protected virtual void Start()
    {
        InvokeRepeating(nameof(AnimateSprite), 0.15f, 0.15f);
    }
    protected virtual void Update()
    {
        if (Input.GetKeyDown(KeyCode.Space))
        {
            direcao = Vector3.up * forca; 
        }
        direcao.y += gravidade * Time.deltaTime;
        transform.position += direcao * Time.deltaTime;
    }

    protected virtual void AnimateSprite()
    {
        spriteIndex++;
        if (spriteIndex >= sprites.Length)
        {
            spriteIndex = 0;
        }

        spriteRenderer.sprite = sprites[spriteIndex];
    }

    protected virtual void OnTriggerEnter2D(Collider2D other)
    {
        
        if (other.gameObject.tag == "obstaculo")
        {
            FindFirstObjectByType<gameManager>().FimDeJogo();
        }
        else if (other.gameObject.tag == "score")
        {
            FindFirstObjectByType<gameManager>().MaisPonto();
        }
    }
}
